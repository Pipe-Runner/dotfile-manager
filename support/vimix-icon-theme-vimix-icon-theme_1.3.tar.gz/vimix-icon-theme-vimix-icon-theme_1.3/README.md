## Vimix Icon Theme
    A Material Design icon theme

Vimix icon theme is based on Paper-Icon-Theme: https://github.com/snwh/paper-icon-theme

## Install Or Uninstall
Run

    ./Installer.sh

Or double-click to open that script files and select "run at the terminal" at nautilus.

## Preview
![vimix](../master/Preview.png)
